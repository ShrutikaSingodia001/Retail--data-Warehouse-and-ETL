# Retail-DatawareHouse-Analytics
This Project aims at creating a data warehouse for e-commerce based company, transforming data in ETL tools like Alteryx and Talend and then performing analytics as per user requirements.
